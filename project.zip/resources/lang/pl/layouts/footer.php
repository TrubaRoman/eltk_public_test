<?php
    return [
        'work-days' => 'Dni robocze',
        'weeks-days'=> [

            'monday'=>'Poniedziałek',
            'tuesday'=>'Wtorek',
            'wednesday'=>'Środa',
            'thursday'=>'Czwartek',
            'friday'=>'Piątek',
            'saturday'=>'Sobota',
            'sunday'=> 'Niedziela',
        ],
        'closed' => 'Zamknięte',
        'menu' => 'Menu'
    ];