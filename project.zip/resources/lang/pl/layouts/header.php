<?php

    return [
        'top-header'=>[
            'left-slogan'=> 'Twój zaufany 24-godzinny dostawc!',
            'right-slogan' => 'Porozmawiaj z ekspertem',
            'call' => 'Połączenie',
            'email' => 'E-mail',
            'address' => 'Adres',
        ],

        'nav' => [
            'employee-cabinet' => 'Strefa pracownika'
        ]
    ];