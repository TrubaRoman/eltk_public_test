<?php
    return [
        '404' => [
            'title' => 'BŁĄD',
            'description' => 'Ta strona mogła zostać przeniesiona lub usunięta. Sprawdź pisownię.',
            'button' => 'Wrócić do domu'
        ]
    ];
