<?php
return
    [
        'email-send-success' =>  'Twoja wiadomość została pomyślnie wysłana!'
    ];