<?php
return
    [
        'email-send-success' =>  'Ваше повідомлення успішно відправлено!'
    ];