<?php
    return [
        'work-days' => 'Робочі дні',
        'weeks-days'=> [

            'monday'=>'Понеділок',
            'tuesday'=>'Вівторок',
            'wednesday'=>'Середа',
            'thursday'=>'Четвер',
            'friday'=>'П’ятниця',
            'saturday'=>'Субота',
            'sunday'=> 'Неділя',
        ],
        'closed' => 'Зачинено',
        'menu' => 'Меню'
    ];