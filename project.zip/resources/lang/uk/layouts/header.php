<?php

    return [
        'top-header'=>[
            'left-slogan'=> 'Ваш надійний постачальник послуг 24 години! ',
            'right-slogan' => 'Поговоріть із експертом',
            'call' => 'Телефон',
            'email' => 'Електронна пошта',
            'address' => 'Адреса',
        ],

        'nav' => [
            'employee-cabinet' => 'Кабінет працівника'
        ]
    ];