<?php
    return [
        '404' => [
            'title' => 'ERROR',
            'description' => 'This page may have been moved or deleted. Be sure to check your spelling.',
            'button' => 'Back To Home'
        ]
    ];
