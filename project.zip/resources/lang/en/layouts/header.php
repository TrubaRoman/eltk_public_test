<?php

    return [
        'top-header'=>[
            'left-slogan'=> 'Your Trusted 24 Hours Service Provider!',
            'right-slogan' => 'Talk To Expert',
            'call' => 'Call',
            'email' => 'Email',
            'address' => 'Address',
        ],

        'nav'=>[
            'employee-cabinet' => 'Employee zone'
        ]


    ];