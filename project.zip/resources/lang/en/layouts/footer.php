<?php
    return [
        'work-days' => 'Work Days',

        'weeks-days'=> [
            'monday'=>'Monday',
            'tuesday'=>'Tuesday',
            'wednesday'=>'Wednesday',
            'thursday'=>'Thursday',
            'friday'=>'Friday',
            'saturday'=>'Saturday',
            'sunday'=> 'Sunday',
        ],

        'closed' => 'Closed',
        'menu' => 'Menu'

    ];