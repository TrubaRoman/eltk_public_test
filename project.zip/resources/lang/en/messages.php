<?php
return
    [
        'email-send-success' =>  'Your message was successfully sent!'
    ];