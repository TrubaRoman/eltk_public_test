<?php
return [
    'view' => 'layouts._breadcrumbs'
];