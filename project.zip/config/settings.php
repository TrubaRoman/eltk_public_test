<?php return array (
  'public_phone' => '+48 609 862 467',
  'public_email' => 'tkoczurek@op.pl',
  'public_address' => '30-669 Kraków. ul Okólna 28 lok. 9',
  'locales' => 
  array (
    0 => 'pl',
    1 => 'uk',
    2 => NULL,
  ),
  'hours_work_open' => '07:03',
  'hours_work_closed' => '17:00',
  'weekend' => 
  array (
    0 => 'sunday',
  ),
  'nip' => '681-117-05-61',
  'sociallinks' => 
  array (
    'facebook' => 'https://laravel.com/docs/facebook',
    'twitter' => 'https://laravel.com/docs/7.x',
  ),
  'workdays' => 
  array (
    0 => 'monday',
    1 => 'tuesday',
    2 => 'wednesday',
    3 => 'thursday',
    4 => 'friday',
    5 => 'saturday',
  ),
);