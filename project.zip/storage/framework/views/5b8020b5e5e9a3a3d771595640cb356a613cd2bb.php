<?php $__env->startComponent('mail::message'); ?>#
#<?php echo e($data->subject, false); ?>

<div class="body-message">
    <?php echo e($data->message, false); ?>

</div>



<?php $__env->startComponent('mail::panel'); ?>

        Imię:    **<?php echo e($data->name, false); ?>**<br>
        Nazwisko:    **<?php echo e($data->surname, false); ?>**<br>
        Email:   [**<?php echo e($data->email, false); ?>**](mailto:<?php echo e($data->email, false); ?>)<br>
        Telefon: **<?php echo e($data->phone, false); ?>**<br>
        Język:   **<?php echo e($data->lang, false); ?>**<br>
        IP:      **<?php echo e($data->ip, false); ?>**<br>
        <?php $__env->startComponent('mail::button', ['url' => 'tel:+'.$data->phone, 'color' => 'site']); ?>
            Oddzwonić
        <?php echo $__env->renderComponent(); ?>

    <?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/resources/views/emails/contactform/cv-mail.blade.php ENDPATH**/ ?>