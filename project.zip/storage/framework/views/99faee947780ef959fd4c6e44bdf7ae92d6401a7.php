<?php $__env->startComponent('mail::message'); ?>

    #<?php echo e($data->subject, false); ?>


        <div class="info-block">
            <h1 class="title-info">Wiadomości ze strony "Oferty pracy"</h1>
            <h2 class="sub-title">Dane osobowe</h2>
            <ul>
                <li>Imię:    <strong><?php echo e($data->name, false); ?></strong><br></li>
                <li>Nazwisko:    <strong><?php echo e($data->surname, false); ?></strong><br></li>
                <li>Email:   <a href="mailto:<?php echo e($data->email, false); ?>"><strong><?php echo e($data->email, false); ?></strong></a><br></li>
                <li>Telefon: <strong><?php echo e($data->phone, false); ?></strong><br></li>
                <li>język przeglądarki: <strong><span style="color:green"><?php echo e($data->lang, false); ?></span></strong><br></li>
                <li>Oferta:<strong><?php echo e($data->offer, false); ?></strong></li>
                <li>Doświadczenie w zawodzie (lata):<?php echo e($data->experianse, false); ?></li>
                <h3>Dodatkowy opis:</h3>
                <p><?php echo e($data->message, false); ?></p>
            </ul>
            <blockquote>
                <h3 class="sub-title">Uprawnienia</h3>
            </blockquote>
            <ul>
                <li>Uprawnienia "SEP" lub równoważne:</li>
                <li>Prawo jazdy:</li>s
                <li>Uprawnienia "SEP":</li>
            </ul>
        </div>


        <?php $__env->startComponent('mail::button', ['url' => 'tel:+'.$data->phone, 'color' => 'site']); ?>
            Oddzwonić
        <?php echo $__env->renderComponent(); ?>


<?php echo $__env->renderComponent(); ?>

<style>
    .info-block{
        padding:2%;
    }
    .title-info{
        border-radius:3px;
        text-align:center;
        color:white;
        padding:2px;
        background: #EE5651;
    }
    .sub-title{
        border-radius:3px;
        text-align:center;
        color:#3065B3;
        padding:1px;
    }
</style>
<?php /**PATH /var/www/resources/views/emails/cv-mail.blade.php ENDPATH**/ ?>