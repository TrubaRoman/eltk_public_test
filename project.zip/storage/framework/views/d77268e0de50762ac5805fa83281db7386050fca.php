[<?php echo e($slot, false); ?>](<?php echo e($url, false); ?>)
<?php /**PATH /var/www/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>