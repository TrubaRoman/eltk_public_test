тестове письмо
<?php /**PATH /var/www/resources/views/emails/contactform/incomingtext.blade.php ENDPATH**/ ?>