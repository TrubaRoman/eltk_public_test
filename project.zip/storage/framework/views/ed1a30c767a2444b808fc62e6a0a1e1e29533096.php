<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

    <?php echo SEOMeta::generate(); ?>


    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('css/layout.css','build'), false); ?>"/>


    <!-- REVOLUTION LAYERS STYLES -->

    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('revolution/css/slider.css','build'), false); ?>"/>

</head>

<body>
<!--page start-->
<div class="page">

    <!-- preloader start -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
    <!-- preloader end -->
<?php echo $__env->make('layouts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('breadcrumbs'); ?>
    <!--site-main start-->
    <?php echo $__env->yieldContent('content'); ?>



    <!--footer start-->
    <footer class="footer widget-footer clearfix">

        <div class="second-footer ttm-textcolor-white">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
                        <div class="widget clearfix">
                            <div class="footer-logo">
                                <img id="footer-logo-img" class="img-center" src="/build/images/footer-logo.png" alt="">
                            </div>
                            <p>Budujemy Twój sukces</p>
                        </div>
                    </div>
                   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
                                                                    <div class="widget widget_text clearfix">
                                                    <h3 class="widget-title"><?php echo e(__('/layouts/footer.work-days'), false); ?></h3>
                                                    <div class="textwidget widget-text">
                                                        <div class="ttm-pricelistbox-wrapper ">
                                                            <div class="ttm-timelist-block-wrapper">
                                                                <ul class="ttm-timelist-block">
                                                                    <?php if(!empty(config('settings.workdays'))): ?>
                                                                    <li><?php echo e(__('/layouts/footer.weeks-days.'.head(config('settings.workdays'))), false); ?> - <?php echo e(__('/layouts/footer.weeks-days.'.last(config('settings.workdays'))), false); ?></li>
                                                                        <li> <?php echo e(config('settings.hours_work_open'), false); ?> - <?php echo e(config('settings.hours_work_closed'), false); ?></li>
                                                                    <?php endif; ?>
                                                                    <?php if(!empty(config('settings.weekend'))): ?>
                                                                            <li><?php echo e(__('/layouts/footer.weeks-days.'.head(config('settings.weekend'))), false); ?> <?php echo e((__('/layouts/footer.weeks-days.'.last(config('settings.weekend'))) !== __('/layouts/footer.weeks-days.'.head(config('settings.weekend'))) )?'-'.__('/layouts/footer.weeks-days.'.last(config('settings.weekend'))):'', false); ?><span class="service-time"><strong><?php echo e(__('/layouts/footer.closed'), false); ?></strong></span></li>

                                                                        <?php endif; ?>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
<?php echo $__env->make('layouts._footer_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
                        <div class="widget widget_text clearfix">
                            <h3 class="widget-title">Kontakt</h3>
                            <div class="textwidget widget-text">
                                <h6 class="ttm-textcolor-skincolor"><a href="tel:<?php echo e(config('settings.public_phone'), false); ?>"><?php echo e(config('settings.public_phone'), false); ?></a></h6>
                                <p class="ttm-textcolor-skincolor"><a href="mail+to:<?php echo e(config('settings.public_email'), false); ?>"><?php echo e(config('settings.public_email'), false); ?></a></p>
                                <p><?php echo e(config('settings.public_address'), false); ?></p>
                                <p>NIP - <?php echo e(config('settings.nip'), false); ?></p>


                            </div>
                            <div class="social-icons">
                                <?php if(count(config('settings.sociallinks'))): ?>

                                <?php endif; ?>
                                <ul class="list-inline">
                                    <?php $__currentLoopData = config('settings.sociallinks'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value !==null): ?>
                                            <li><a href="<?php echo e($value, false); ?>"><i class="fa fa-<?php echo e($name, false); ?>" aria-hidden="true"></i></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="bottom-footer-text ttm-textcolor-white">
            <div class="container">
                <div class="row copyright">
                    <div class="col-md-8 ttm-footer2-left">
                        <span>Copyright © 2020&nbsp;<a href="<?php echo e(config('app.url'), false); ?>"><?php echo e(config('app.name'), false); ?></a>. All rights reserved.</span>
                    </div>
                    <div class="col-md-4 ttm-footer2-right">

                        <span>Development <i class="fa fa-code"></i> 2020&nbsp;<a href="mail+to:trubaroman571@gmail.com">trubaroman571@gmail.com</a></span>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--footer end-->

    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>

    <!--back-to-top end-->


</div><!-- page end -->


<!-- Javascript -->

<script src="<?php echo e(mix('js/layout.js','build'), false); ?>"></script>

<!-- Revolution Slider -->
<script src="<?php echo e(mix('revolution/js/slider.js','build'), false); ?>"></script>
<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="<?php echo e(mix('revolution/js/extensions/extensions-slider.js','build'), false); ?>"></script>


<script type="text/javascript">
    $(function(){
        $("#phone").mask("+(99) 999-999-999");
    });
</script>

<?php if( Route::currentRouteName() == 'contacts' ): ?>
    <?php echo $__env->make('layouts._ajax_contactform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Route::currentRouteName() == 'offers'  ): ?>
    <?php echo $__env->make('layouts._ajax_job_offerts_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</body>

</html><?php /**PATH /var/www/resources/views/layouts/main.blade.php ENDPATH**/ ?>