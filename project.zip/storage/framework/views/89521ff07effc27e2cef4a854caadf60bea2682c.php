<?php echo e($slot, false); ?>

<?php /**PATH /var/www/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>