<?php if( Session::has("success") ): ?>
    <div class="alert text-success" role="alert">

        <?php echo e(Session::get("success"), false); ?>

    </div>
<?php endif; ?>


<?php if( Session::has("error") ): ?>
    <div class="alert alert-danger alert-block" role="alert">

        <?php echo e(Session::get("error"), false); ?>

    </div>
<?php endif; ?><?php /**PATH /var/www/resources/views/layouts/_flash.blade.php ENDPATH**/ ?>