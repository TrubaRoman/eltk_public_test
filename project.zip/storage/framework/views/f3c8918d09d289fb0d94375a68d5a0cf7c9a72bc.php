
<div class="row ttm-fid-row-wrapper">
    <?php $__currentLoopData = $counter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-4">
        <div class="ttm-fid inside ttm-fid-view-lefticon">
            <div class="ttm-fid-left">
                <div class="ttm-fid-icon-wrapper">
                    <i class="ti <?php echo e($item->icon, false); ?>"></i>
                </div>
                <h4 class="ttm-fid-inner">
                                                <span   data-appear-animation = "animateDigits"
                                                        data-from             = "0"
                                                        data-to               = "<?php echo e($item->int_count, false); ?>"
                                                        data-interval         = "<?php echo e($item->int_count / mt_rand(2,10), false); ?>"
                                                        data-before           = ""
                                                        data-before-style     = "sup"
                                                        data-after            = ""
                                                        data-after-style      = "sub"
                                                ><?php echo e($item->int_count, false); ?></span><span>+</span>
                </h4>
            </div>
            <div class="ttm-fid-contents">
                <h3 class="ttm-fid-title"><?php echo e($item->title, false); ?></h3>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /var/www/resources/views/layouts/_counters.blade.php ENDPATH**/ ?>