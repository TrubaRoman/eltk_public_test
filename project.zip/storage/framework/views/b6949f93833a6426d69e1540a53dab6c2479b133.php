<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">

<head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

    <title>503</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('css/layout.css','build'), false); ?>"/>


    <!-- REVOLUTION LAYERS STYLES -->

    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('revolution/css/slider.css','build'), false); ?>"/>

</head>

<body>

<body>

<!--page start-->
<div class="page">

    <!--header start-->
    <header id="masthead" class="header ttm-header-style-classic">
        <!-- ttm-topbar-wrapper -->
        <div class="ttm-topbar-wrapper ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">

        </div><!-- ttm-topbar-wrapper end -->
        <!-- ttm-header-wrap -->
        <div class="ttm-header-wrap">
            <!-- ttm-stickable-header-w -->

        </div><!--ttm-header-wrap end -->
    </header><!--header end-->

    <!--error-404 start-->
    <section class="error-404 bg-img3">
        <div class="ttm-big-icon ttm-textcolor-skincolor">
            <i class="fa fa-gears"></i>
        </div>
        <header class="page-header"><h1 class="page-title">503 ERROR</h1></header>
        <div class="page-content"> <p>Service Temporarily Unavailable.</p></div>

    </section>
    <!--error-404 end-->

    <!--footer start-->
    <footer class="footer widget-footer clearfix">

    </footer>
    <!--footer end-->


</div><!-- page end -->



</body>

<script src="<?php echo e(mix('js/layout.js','build'), false); ?>"></script>
<?php /**PATH /var/www/resources/views/errors/503.blade.php ENDPATH**/ ?>