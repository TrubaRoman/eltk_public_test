
Is text<?php /**PATH /var/www/resources/views/emails/cv-mail-plain.blade.php ENDPATH**/ ?>