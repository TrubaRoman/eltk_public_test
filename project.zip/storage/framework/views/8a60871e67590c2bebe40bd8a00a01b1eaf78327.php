<?php echo e($slot, false); ?>: <?php echo e($url, false); ?>

<?php /**PATH /var/www/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>