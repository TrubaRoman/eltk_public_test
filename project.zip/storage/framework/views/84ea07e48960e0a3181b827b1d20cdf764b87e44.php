<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts._breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--site-main start-->
    <div class="site-main">

        <!-- service-section -->
        <section class="ttm-row services2-section pb-110 clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <!-- section title -->
                        <div class="section-title with-desc title-style-center_text clearfix">
                            <div class="title-header">
                                <h5>OUR SERVICES</h5>
                                <h2 class="title">What You Will Get Form<br>Us Check It</h2>
                            </div>
                            <div class="title-desc">Raising a heavy fur muff that covered the whole of her lower arm towards the viewer regor then turned to look out the window</div>
                        </div><!-- section title end -->
                    </div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row mt-10">

                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-4 d-flex align-items-streach">
                        <!-- featured-imagebox -->
                        <div class="featured-imagebox box-shadow2 mb-30">
                            <div class="featured-thumbnail" style="min-height: 270px">
                                <img class="img-fluid" src="<?php echo e($item->getLastImage(), false); ?>" alt="">
                            </div>
                            <div class="ttm-box-bottom-content">
                                <div class="featured-title featured-title">
                                    <h5><a href="<?php echo e(route('services.show',[app()->getLocale(),$item->slug]), false); ?>"><?php echo e($item->localization->title, false); ?></a></h5>
                                </div>
                                <div class="featured-desc pb-20" >
                                    <p><?php echo e($item->localization->short_content, false); ?></p>

                                    <div class="self-item ">
                                        <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-icon-btn-right ttm-btn-style-border ttm-btn-color-black mb-10" href=" <?php echo e(route('services.show',[app()->getLocale(),$item->slug]), false); ?>">MORE DETAILS<i class="ti ti-angle-double-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- featured-imagebox end-->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- row end -->
            </div>
        </section>
        <!-- service-section end -->

    </div><!--site-main end-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/services/index.blade.php ENDPATH**/ ?>