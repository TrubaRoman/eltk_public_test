<?php if($menuitems): ?>
<?php

    function buildMenu($menuitems, $parent)
    {
        foreach ($menuitems  as $item)
            {
                 if (isset($item->children)) {
?>

<li><a href="<?php echo e($item->url, false); ?>"><?php echo e($item->name, false); ?></a>
    <ul>
        <?php buildMenu($item->children, 'subnav-'.$item->id) ?>
    </ul>
</li>
<?php
    }else{
?>
<li class="<?php echo e(request()->routeIs($item->url)?'active':'', false); ?>" >
    <a href="<?php echo e(url(app()->getLocale(),$item->url), false); ?>"  ><?php echo e($item->name, false); ?></a>
</li>
<?php
    }
}
}
buildMenu($menuitems, 'mainMenu');
?>
    <?php endif; ?>

<?php $__currentLoopData = $menufooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Route::currentRouteName() == $item->url): ?>
        <?php $__env->startSection('breadcrumbs',\DaveJamesMiller\Breadcrumbs\Facades\Breadcrumbs::render($item->url,$item)); ?>
        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/resources/views/layouts/_script_nav.blade.php ENDPATH**/ ?>