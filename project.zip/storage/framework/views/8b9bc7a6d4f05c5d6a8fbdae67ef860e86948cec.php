<?php echo e($slot, false); ?>

<?php /**PATH /var/www/resources/views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>