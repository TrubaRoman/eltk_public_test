<?php $__env->startSection('content'); ?>


    <div class="site-main">

        <section class="ttm-row pt-60 pb-110 res-991-pb-70 ttm-bgcolor-grey clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <h2><strong>Our Latest Projects</strong></h2>
                        <p class="mb-55">Below you’ll see our best industrial projects.&nbsp; We are providing&nbsp;never ending customer support also provide guarantee a very high level of satisfaction for our clients.&nbsp;&nbsp;if you have a question&nbsp; don’t hesitate to email us at <a href="#">info@example.com</a>&nbsp;for more details.</p>
                    </div>
                </div><!-- row end -->
                <div class="row">
                    <?php if($portfolios != null): ?>
                       <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-6">
                        <!-- featured-imagebox -->
                        <div class="featured-imagebox featured-imagebox-portfolio ttm-box-view-top-image">
                            <div class="ttm-box-view-content-inner">
                                <!-- featured-thumbnail -->
                                <div class="featured-thumbnail">
                                    <a href="#"> <img class="img-fluid" src="<?php echo e($item->getLastImage(), false); ?>" alt="<?php echo e($item->alt_image, false); ?>"></a>
                                </div><!-- featured-thumbnail end-->
                                <!-- ttm-box-view-overlay -->
                                <div class="ttm-box-view-overlay">
                                    <div class="featured-iconbox ttm-media-link">
                                        <a class="ttm_prettyphoto ttm_image" title="Plumbing, New York" data-rel="prettyPhoto" href="<?php echo e($item->getLastImage(), false); ?>"><i class="ti ti-search"></i></a>
                                        <a href="<?php echo e(route('portfolio.show',[app()->getLocale(),$item->slug]), false); ?>" class="ttm_link"><i class="ti ti-link"></i></a>
                                    </div>
                                </div><!-- ttm-box-view-overlay end-->
                            </div>
                            <div class="ttm-box-bottom-content featured-content-portfolio box-shadow2">
                                <span class="category">
                                    <p><?php echo e($item->client, false); ?>,
                                    <?php echo e($item->duration, false); ?></p>
                                </span>
                                <h2 class="featured-title"><a href="<?php echo e(route('portfolio.show',[app()->getLocale(),$item->slug]), false); ?>"><?php echo e($item->localization->title, false); ?></a></h2>
                            </div>
                        </div><!-- featured-imagebox -->
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

    </div><!--site-main end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/portfolios/index.blade.php ENDPATH**/ ?>