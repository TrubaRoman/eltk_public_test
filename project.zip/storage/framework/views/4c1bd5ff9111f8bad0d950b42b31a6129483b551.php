<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts._breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--site-main start-->
    <div class="site-main">

        <!-- about-section -->
        <section class="ttm-row about3-section ttm-bgcolor-grey">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <!-- single-img -->
                        <div class="single-img mb-40">
                            <img class="img-fluid" src="<?php echo e($abouts->getLastImage(), false); ?>" alt="<?php echo e($abouts->alt_img, false); ?>">
                        </div><!-- single-img end -->
                    </div>
                    <div class="col-lg-6 col-sm-12 pl-0 res-991-pl-15">
                        <!-- section title -->
                        <div class="section-title clearfix">
                            <div class="title-header">
                                <h5>WHO WE ARE</h5>
                                <h2 class="title"><?php echo e($abouts->localization->title, false); ?></h2>
                            </div>
                        </div><!-- section title end -->
                        <!-- acadion -->
                        <div class="accordion mt-40">
                          <?php echo $abouts->localization->content; ?>

                            <?php echo $__env->make('layouts._counters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- acadion end-->

                    </div>

                </div><!-- row end-->

            </div>
        </section>
        <!-- about-section end -->


        <!--services-section-->
        <section class="ttm-row clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!-- section-title -->
                        <div class="section-title style2 clearfix">
                            <div class="title-header">
                                <h5>WORKING WITH EXCELLENT</h5>
                                <h2 class="title">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, quos.</h2>
                            </div>
                            <div class="title-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias aspernatur eos iusto magni molestiae neque possimus reprehenderit sequi temporibus voluptatum!</div>
                        </div><!-- section-title end -->
                    </div>

                </div><!-- row end -->
                <!-- row -->

            </div>
        </section>
        <!--services-section end-->

        <!-- testimonial-section -->

        <!-- testimonial-section end-->


        <!-- partners-section -->

        <!-- partners-section end -->

        <!--team-section-->

        <!--team-section end-->

    </div><!--site-main end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/abouts/index.blade.php ENDPATH**/ ?>