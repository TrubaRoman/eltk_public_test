<?php if($count != null): ?>
<li>
    <a href="<?php echo e(route('contacts.index'), false); ?>">
        <b> Nowe wiadomości:  </b> <i class="fa fa-envelope-o"></i>
        <span class="label label-success"><?php echo e($count, false); ?></span>
    </a>
</li>
<?php endif; ?>

<?php /**PATH /var/www/resources/views/admin/header/_nav.blade.php ENDPATH**/ ?>