<nav id="menu" class="menu">
    <ul class="dropdown">
        <li class="active"><a href="<?php echo e(route('home',app()->getLocale()), false); ?>">Home</a>

        </li>

        <li>
            <a href="<?php echo e(route('services',app()->getLocale()), false); ?>">Services</a>
        </li>


        <li><a href="#">Projects</a>
            <ul>
                <li><a href="portfolio-style-1.html">Project Style 1</a></li>
                <li><a href="portfolio-style-2.html">Project Style 2</a></li>
                <li><a href="#">Project Single</a>
                    <ul>
                        <li><a href="single-style-1.html">Style One</a></li>
                        <li><a href="single-style-2.html">Style Two</a></li>
                        <li><a href="single-style-3.html">Style Three</a></li>
                    </ul>
                </li>
            </ul>
        </li>


        <?php

        function buildMenu($menuitems, $parent)
        {
            foreach ($menuitems  as $item)
                {
                     if (isset($item->children)) {
        ?>

                <li><a href="<?php echo e($item->url, false); ?>"><?php echo e($item->name, false); ?></a>
                    <ul>
                        <?php buildMenu($item->children, 'subnav-'.$item->id) ?>
                    </ul>
                </li>
        <?php
        }else{
        ?>
        <li c>
            <a href="<?php echo e($item->url, false); ?>" ><?php echo e($item->name, false); ?></a>
        </li>
        <?php
                     }
                }
        }
          buildMenu($menuitems, 'mainMenu');
        ?>








        <li><a href="#" ><img src="/build/img/flags/24/<?php echo e(app()->getLocale(), false); ?>.png">	&#8195;<?php echo e(strtoupper(app()->getLocale()), false); ?></a>
            <ul>
                <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a  href="<?php echo e(route(\Illuminate\Support\Facades\Route::currentRouteName(), $locale), false); ?>">
                            <img src="/build/img/flags/24/<?php echo e($locale, false); ?>.png" alt=""> 	&#8195;&#8195;<?php echo e(strtoupper($locale), false); ?> </a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
    </ul>
</nav>
<?php /**PATH /var/www/resources/views/layouts/_script_nav.blade.php ENDPATH**/ ?>