<div class="widget widget_nav_menu clearfix">
    <h3 class="widget-title"><?php echo e(__('/layouts/footer.menu'), false); ?></h3>
    <ul id="menu-footer-services">

        <?php $__currentLoopData = $menufooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$item->children): ?>
                    <li ><a href="<?php echo e(url(app()->getLocale(),$item->url), false); ?>"><?php echo e($item->name, false); ?></a></li>
                    <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /var/www/resources/views/layouts/_footer_nav.blade.php ENDPATH**/ ?>