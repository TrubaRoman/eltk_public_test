<div class="btn-group" data-toggle="buttons">
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="btn btn-default btn-sm <?php echo e(\Request::get('gender', 'all') == $option ? 'active' : '', false); ?>">
            <input type="radio" class="user-gender" value="<?php echo e($option, false); ?>"><?php echo e($label, false); ?>

        </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /var/www/resources/views/admin/tools/gender.blade.php ENDPATH**/ ?>