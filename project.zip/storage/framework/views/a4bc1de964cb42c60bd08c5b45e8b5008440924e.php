<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot), false); ?>

</div>
<?php /**PATH /var/www/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/table.blade.php ENDPATH**/ ?>