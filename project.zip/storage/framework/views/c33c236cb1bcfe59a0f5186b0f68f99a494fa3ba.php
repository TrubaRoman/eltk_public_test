<?php $__env->startSection('breadcrumbs',''); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('home._slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="site-main">
        <!--row-top-section-->
        <!-- row-text-section -->
        <section class="ttm-row row-text-section ttm-bgcolor-grey">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="sep-box text-center">
                            <h2>Firma, która najlepiej zadba o Twoją instalację elektryczną</h2>
                            <h6>Friendly customer service staff for your all questions!</h6>
                            <div class="sep_holder_box width-30 pt-10">
                                <span class="sep_holder"><span class="sep_line"></span></span>
                                <div class="ttm-icon ttm-icon_element-color-skincolor ttm-icon_element-size-lg">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <span class="sep_holder"><span class="sep_line"></span></span>
                            </div>
                            <h4>Toll Free: 1800-200-45678</h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- row-text-section end -->
        <!-- about-section -->
        <section class="ttm-row about2-section break-1199-colum clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <!-- ttm_single_image-wrapper -->
                        <div class="ttm_single_image-wrapper mb-5">
                            <img class="img-fluid" src="build/images/single-img-three.jpg" alt="">
                        </div><!-- ttm_single_image-wrapper end -->
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div class="pt-20">
                            <div class="row">






                                <div class="col-lg-8">
                                    <!-- section title -->
                                    <div class="section-title with-desc mt-10 pb-10 clearfix">
                                        <div class="title-header">
                                            <h5><?php echo e(__('content/pages.about.sub_title'), false); ?></h5>
                                            <h2 class="title"><?php echo e(__('content/pages.about.title'), false); ?></h2>
                                        </div>
                                    </div><!-- section title end -->
                                </div>
                            </div>
                            <!-- section title -->

                            <div class="section-title with-desc clearfix">
                                <div class="title-desc">
                                    <strong><?php echo e($abouts_main->localization->title, false); ?></strong>
                                </div>
                            </div><!-- section title end -->
                            <p><?php echo $abouts_main->localization->content; ?></p>

                                <!-- row-->
                            <?php echo $__env->make('layouts._counters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </section>


        <!-- about-section end -->

        <!--services-box-section-->
        <section class="ttm-row services-box-section bg-img12 clearfix">
            <div class="container">
                <div class="row row-equal-height">
<?php $__currentLoopData = $abouts_block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <!-- featured-icon-box -->
                        <div class="featured-icon-box style1 top-icon text-center ttm-bgcolor-white box-shadow2">
                            <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-background-color-skincolor ttm-icon_element-size-md ttm-icon_element-style-rounded">
                                <i class="fa <?php echo e($item->icons, false); ?>"></i>
                            </div>
                            <div class="featured-content">
                                <div class="featured-title">
                                    <h5><?php echo e($item->localization->title, false); ?></h5>
                                </div>
                                <div class="featured-desc">
                                    <p><?php echo $item->localization->content; ?></p>
                                </div>
                            </div>
                        </div><!-- featured-icon-box end-->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- row end -->
            </div>
        </section>
        <!-- services-box-section end -->
        <!-- service-section -->
        <section class="ttm-row services2-section pb-110 clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <!-- section title -->
                        <div class="section-title with-desc title-style-center_text clearfix">
                            <div class="title-header">
                                <h5></h5>
                                <h2 class="title"><?php echo e(__('content/pages.services.title'), false); ?></h2>
                            </div>
                            <div class="title-desc"><?php echo e(__('content/pages.services.short_text'), false); ?></div>
                        </div><!-- section title end -->
                    </div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row mt-10">
                    
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-4 d-flex align-items-streach">
                            <!-- featured-imagebox -->
                            <div class="featured-imagebox box-shadow2 mb-30">
                                <div class="featured-thumbnail" style="min-height: 270px">
                                    <img class="img-fluid" src="<?php echo e($item->getLastImage(), false); ?>" alt="">
                                </div>
                                <div class="ttm-box-bottom-content">
                                    <div class="featured-title featured-title">
                                        <h5><a href="<?php echo e(route('services.show',[app()->getLocale(),$item->slug]), false); ?>"><?php echo e($item->localization->title, false); ?></a></h5>
                                    </div>
                                    <div class="featured-desc pb-20" >
                                        <p><?php echo e($item->localization->short_content, false); ?></p>

                                        <div class="self-item ">
                                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-icon-btn-right ttm-btn-style-border ttm-btn-color-black mb-10" href=" <?php echo e(route('services.show',[app()->getLocale(),$item->slug]), false); ?>"><?php echo e(__('content/pages.buttons.more_details'), false); ?><i class="ti ti-angle-double-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- featured-imagebox end-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- row end -->
            </div>
        </section>
        <!-- service-section end -->

    </div><!--site-main end-->
    <script>

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/home/index.blade.php ENDPATH**/ ?>