<?php $__env->startSection('content'); ?>
<?php $__env->startSection('breadcrumbs',\DaveJamesMiller\Breadcrumbs\Facades\Breadcrumbs::render('services.show',$service_item)); ?>
    <!--site-main start-->


        <!-- sidebar -->
        <div class="sidebar ttm-sidebar-left ttm-bgcolor-white break-991-colum clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
<?php echo $__env->make('services._widget_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-lg-9 content-area">
                        <!-- ttm-service-single-content-are -->
                        <div class="ttm-service-single-content-area">

                            <h3><?php echo e($service_item->localization->title, false); ?></h3>
                            <div class="ttm_single_image-wrapper mb-35">
                                <img class="img-fluid" src="<?php echo e($service_item->getLastImage(), false); ?>" alt="">
                            </div>
                            <div class="mb-35">
                                <?php echo $service_item->localization->content; ?>

                            </div>
                            <div class="sep_holder_box width-100">
                                <span class="sep_holder m-0 mb-35"><span class="sep_line"></span></span>
                                <span class="sep_holder m-0 mb-35"><span class="sep_line"></span></span>
                            </div>

                        </div>
                        <!-- ttm-service-single-content-are end -->
                    </div>
                </div><!-- row end -->
            </div>
        </div>
        <!-- sidebar end -->



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/services/show.blade.php ENDPATH**/ ?>