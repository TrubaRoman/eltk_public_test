
<!-- page-title -->
<?php if(isset($breadcrumbs) && count($breadcrumbs)): ?>
<div class="ttm-page-title-row">
    <div class="ttm-page-title-row-bg-layer ttm-bg-layer"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-box ttm-textcolor-white">

                    <div class="breadcrumb-wrapper">
                        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($breadcrumb->url && !$loop->last): ?>
                                <span>
                                    <a title="Homepage" href="<?php echo e($breadcrumb->url,app()->getLocale(), false); ?>"><?php echo e($breadcrumb->title, false); ?></a>
                                </span>
                        <span class="ttm-bread-sep">&nbsp; / &nbsp;</span>
                        <?php else: ?>
                        <span><span><?php echo e($breadcrumb->title, false); ?></span></span>
                    </div>



                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><!-- /.col-md-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</div><!-- page-title end-->
    <?php endif; ?><?php /**PATH /var/www/resources/views/layouts/_breadcrumbs.blade.php ENDPATH**/ ?>